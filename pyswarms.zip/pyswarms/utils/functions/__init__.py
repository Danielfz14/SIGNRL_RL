"""
The mod:`pyswarms.utils.functions` module implements various test functions
for optimization.
"""
